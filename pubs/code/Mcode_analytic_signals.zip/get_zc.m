%-------------------------------------------------------------------------------
% Get 'conventional' discrete analytic signal, z_c[n].  See [1] for details.
%
% [1] J. M. O' Toole, M. Mesbah, and B. Boashash, "A New Discrete Analytic Signal 
%     for Reducing Aliasing in the Discrete Wigner-Ville
%     Distribution", IEEE Trans. on Signal Processing, vol. 56,
%     no. 11, pp. 5427--5434, Nov. 2008.


% Copyright (C) 2007,2008 John M. O' Toole, University of Queensland
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------------
function [zc,Zc]=get_zc(s1);
N=length(s1); s1=s1(:);
zc=analytic_CB(real(s1));
zc=[zc.', zeros(1,N)].';

if( nargout>1 ) Zc=fft(zc); end
