%-------------------------------------------------------------------------------
% Discrete analytic signal, using the Cizek--Bonzangio method, also described
% in [1]
%
%
% [1] S. Lawrence Marple, Jr., Computing the discrete-time analytic
%     signal via FFT, IEEE Transactions on Signal Processing, Vol. 47,
%     No. 9, September 1999, pp.2600--2603.

% STARTED: 14-05-2008

% Copyright (C) 2007,2008 John M. O' Toole, University of Queensland
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------------
function z=analytic_CB(s1);
s1=real(s1);
N=length(s1);
S1=fft(s1);

H  = zeros(N,1); 
if N > 0 && 2*fix(N/2) == N
  % even and nonempty
  H([1 N/2+1]) = 1;
  H(2:N/2) = 2;
elseif N>0
  % odd and nonempty
  H(1) = 1;
  H(2:(N+1)/2) = 2;
end

z=ifft(S1.*H);

