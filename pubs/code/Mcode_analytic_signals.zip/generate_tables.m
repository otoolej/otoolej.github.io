%-------------------------------------------------------------------------------
% Compare the conventional and proposed analytic signals using the
% ratio mesures in [1].  This function generates Tables 1 and 2 from
% [1].
%
% USE:     generate_tables( tab );
% 
% INPUT: tab = { 1 | 2 } 1 for table I and 2 for table II.
%
% EXAMPLE
%      generate_tables(1);
%      generate_tables(2);
%
%
% [1] J. M. O' Toole, M. Mesbah, and B. Boashash, "A New Discrete
%     Analytic Signal for Reducing Aliasing in the Discrete
%     Wigner-Ville Distribution", IEEE Trans.  on Signal Processing,
%     vol. 56, no. 11, pp. 5427--5434, Nov. 2008.
%

% Copyright (C) 2007,2008 John M. O' Toole, University of Queensland
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------------
function generate_tables(table);
if(nargin<1) table=1; end
if( table~=1 && table~=2 )
  error('Use: generate_tables(tab) where tab is either 1 or 2');
end


%---------------------------------------------------------------------
% Which type of signals do we want to test for?
% (set to zero to omit from tests)
%---------------------------------------------------------------------
IMPULSE_SIG=1;
STEP_SIG=1;
SIN_SIG=1;
NLFM_SIG=1;
WGN_SIGS=1;
EEG_SIGS=1;



e_ratio_impulse=zeros(2,1);
e_ratio_step=zeros(2,1);
e_ratio_sin=zeros(2,1);
e_ratio_nlfm=zeros(2,1);
e_ratio_wgn=zeros(2,2);
e_ratio_eeg=zeros(2,2);


if(IMPULSE_SIG)
  load('test_signals.mat','impulse_sig','impulse_sig_odd');
  
  e_ratio_impulse=calculate_ratios(impulse_sig,length(impulse_sig), ...
                                   impulse_sig_odd, ...
                                   length(impulse_sig_odd),table);
end


if(STEP_SIG)
  load('test_signals.mat','step_sig','step_sig_odd');
  
  e_ratio_step=calculate_ratios(step_sig,length(step_sig),step_sig_odd, ...
                                length(step_sig_odd),table);
end


if(SIN_SIG)
  load('test_signals.mat','sin_sig','sin_sig_odd');

  e_ratio_sin=calculate_ratios(sin_sig,length(sin_sig),sin_sig_odd, ...
                               length(sin_sig_odd),table);
end


if(NLFM_SIG)
  load('test_signals.mat','nlfm_sig','nlfm_sig_odd');

  e_ratio_nlfm=calculate_ratios(nlfm_sig,length(nlfm_sig),nlfm_sig_odd, ...
                                length(nlfm_sig_odd),table);
end


if(EEG_SIGS)
  load('test_signals.mat','eeg_epochs');
  
  [Niter,N1]=size(eeg_epochs);
  eeg_ratio=zeros(Niter,2);
  
  
  for n=1:Niter
    eeg_even=eeg_epochs(n,1:N1);
    eeg_odd=eeg_epochs(n,1:(N1-1));        
    eeg_ratio(n,:)=calculate_ratios(eeg_even,length(eeg_even),eeg_odd, ...
                                    length(eeg_odd),table);
  end
  % For even length epochs:
  e_ratio_eeg(1,1)=mean(eeg_ratio(:,1));
  e_ratio_eeg(1,2)=std(eeg_ratio(:,1));  

  % For odd length epochs:
  e_ratio_eeg(2,1)=mean(eeg_ratio(:,2));
  e_ratio_eeg(2,2)=std(eeg_ratio(:,2));  
end



if(WGN_SIGS)
  Niter=1000; N1=128;
  r1=randn(Niter,N1);
  r1_odd=randn(Niter,N1+1);

  wgn_ratio=zeros(Niter,2);
  
  
  for n=1:Niter
    wgn_ratio(n,:)=calculate_ratios(r1(n,:),N1,r1_odd(n,:),N1+1,table);
  end
  % For even length epochs:
  e_ratio_wgn(1,1)=mean(wgn_ratio(:,1));
  e_ratio_wgn(1,2)=std(wgn_ratio(:,1));  

  % For odd length epochs:
  e_ratio_wgn(2,1)=mean(wgn_ratio(:,2));
  e_ratio_wgn(2,2)=std(wgn_ratio(:,2));  
end


pretty_print_table( e_ratio_impulse, e_ratio_step, e_ratio_sin, ...
                    e_ratio_nlfm, e_ratio_wgn, e_ratio_eeg, table );


return;


%---------------------------------------------------------------------
% Get the ratios
%---------------------------------------------------------------------
function e_ratio=calculate_ratios(sig_even,N_even,sig_odd,N_odd,table)

if(table==2)
  e_ratio(1)=df_spectral_leakage_ratio(sig_even);
  e_ratio(2)=df_spectral_leakage_ratio(sig_odd);        
else
  e_ratio(1)=get_spectral_energy_ratios(sig_even,N_even);
  e_ratio(2)=get_spectral_energy_ratios(sig_odd,N_odd);        
end





%---------------------------------------------------------------------
% Calculate spectral energy relation between the two analytic signals.
%---------------------------------------------------------------------
function E_ratio=get_spectral_energy_ratios(s1,N1)
zc=get_zc(s1); zp=get_zp(s1); 
Zc=fft(zc); Zp=fft(zp);

k=N1:(2*N1-1);
E_zc = sum( abs(Zc(k+1)).^2 );
E_zp = sum( abs(Zp(k+1)).^2 );
E_ratio = E_zp/E_zc;


%---------------------------------------------------------------------
% Display table with results
%---------------------------------------------------------------------
function pretty_print_table( r_impulse, r_step, r_sin, r_nlfm, r_wgn, ...
                             r_eeg,table )
if(table==1)
  disp('          - Table 1  -');
else
  disp('          - Table 2  -');  
end

disp('---------------------------------');
disp('Signal Type   N even      N odd');
disp('---------------------------------');
disp(['Impulse       ' num_to_string(r_impulse(1)) '   ' ...
      num_to_string(r_impulse(2))]);
disp(['Step          ' num_to_string(r_step(1)) '   ' ...
      num_to_string(r_step(2))]);
disp(['Sin           ' num_to_string(r_sin(1)) '   ' num_to_string(r_sin(2))]);
disp(['NLFM          ' num_to_string(r_nlfm(1)) '   ' ...
      num_to_string(r_nlfm(2))]);
disp(['EEG (mean)    ' num_to_string(r_eeg(1,1)) '   ' ...
      num_to_string(r_eeg(2,1))]);
disp(['EEG (std)     ' num_to_string(r_eeg(1,2)) '  ' ...
      num_to_string(r_eeg(2,2))]);
disp(['WGN (mean)    ' num_to_string(r_wgn(1)) '   ' num_to_string(r_wgn(2))]);
disp(['WGN (std)     ' num_to_string(r_wgn(3)) '  ' num_to_string(r_wgn(4))]);
disp('---------------------------------');



function str=num_to_string(x)
if(x==0) 
  str='  -  ';
else
  str=num2str(x);
end





%---------------------------------------------------------------------
% Return ratio of spectral-leakage in doppler--frequency function
% using the two analytic signals.
%---------------------------------------------------------------------
function E_ratio_k=df_spectral_leakage_ratio(s1)
N=length(s1); N2=2*N;
zc=get_zc(s1); zp=get_zp(s1);
Zc=fft(zc);  Zp=fft(zp); 
lKsiaf_zc=zeros(N2); lKsiaf_zp=zeros(N2);


%% 1. Negative doppler half.
l=N:(N2-1);
for k=0:N2-1
  b1=mod(k-l,N2);
  lKsiaf_zc(l+1,k+1) = Zc(l+1).*conj( Zc(b1+1) );
  lKsiaf_zp(l+1,k+1) = Zp(l+1).*conj( Zp(b1+1) );  
end


%% 2. Positive doppler half.
for k=0:N
  l=(k+1):N;
  b1=mod(k-l,N2);
  lKsiaf_zc(l+1,k+1) = Zc(l+1).*conj( Zc(b1+1) );
  lKsiaf_zp(l+1,k+1) = Zp(l+1).*conj( Zp(b1+1) );  
end


for k=N:(N2-1)
  l=0:(k-N);
  b1=mod(k-l,N2);
  lKsiaf_zc(l+1,k+1) = Zc(l+1).*conj( Zc(b1+1) );
  lKsiaf_zp(l+1,k+1) = Zp(l+1).*conj( Zp(b1+1) );  
end


E_k_zc=sum(sum(abs(lKsiaf_zc).^2));
E_k_zp=sum(sum(abs(lKsiaf_zp).^2));
E_ratio_k = E_k_zp/E_k_zc;


