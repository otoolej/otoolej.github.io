%-------------------------------------------------------------------------------
% Generate the DWVD W(nT/2,k/4NT) from 2N-point signal, as defined in
% [1].
% 
%
% USE: wvd=dwvd_B(z1)
%
% INPUT:
%      z1 - 2N-point time-domain signal
%
% OUTPUT: 
%      wvd - 2N x 2N DWVD  
%
% EXAMPLE
%      N=64;  f=0.3; N2=2*N;
%      s=cos( 2*pi*f.*(0:N-1) );     
%      z=get_zp(s);
%      w=dwvd_B(z); 
%      mesh(w); 
%      xlabel('frequency');  ylabel('time');
%
%
% [1] F. Peyrin and R. Prost, "A unified definition for the
%     discrete-time, discrete-frequency, and discrete-time/frequency
%     Wigner distributions," IEEE Trans. Acoust., Speech, Signal
%     Processing, vol. 34, no. 4, pp. 858­866, Aug. 1986.
%


% Copyright (C) 2007,2008 John M. O' Toole, University of Queensland
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------------
function wvd=dwvd_B(z1)
N2=length(z1); N=N2/2;
if( N~=fix(N2/2))
  error('Must use 2N-point signal.');
end


%---------------------------------------------------------------------
% 1. Form time--lag signal function
%---------------------------------------------------------------------
K=zeros(N2);
n=0:N-1;
for m=0:N2-1
  i1=mod(n+m,N2); i2=mod(n-m,N2); i3=mod(n+m+1,N2);
  K(2.*n+1,m+1)=z1(i1+1).*conj(z1(i2+1));
  K(2.*n+2,m+1)=z1(i3+1).*conj(z1(i2+1));  
end

  

%---------------------------------------------------------------------
% 2. Transform to the time--frequency domain
%---------------------------------------------------------------------
wvd=fft(K.').';
wvd=wvd./N2;
k=0:N2-1;
md = exp( -j*(pi/N2).*k );
for n=0:2:N2-1
  wvd(n+2,:)=wvd(n+2,:).*md;
end

wvd=real(wvd);

