%-------------------------------------------------------------------------------
% Plot figures from [1].
%
% USE:   plot_figures( fig )
% 
% INPUT: fig = { 'fig1' | 'fig2' | 'fig3a' | 'fig3b' | 'fig4' | 'fig5' }
%
% EXAMPLE
%       plot_figures('fig3a');
%       plot_figures('fig5');
%
%
% [1] J. M. O' Toole, M. Mesbah, and B. Boashash, "A New Discrete
%     Analytic Signal for Reducing Aliasing in the Discrete
%     Wigner-Ville Distribution", IEEE Trans.  on Signal Processing,
%     vol. 56, no. 11, pp. 5427--5434, Nov. 2008.
%

% Copyright (C) 2007,2008 John M. O' Toole, University of Queensland
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------------
function plot_figures(fig_type);
if( nargin<1 ) fig_type='fig1'; end


FREQ_DOMAIN=1;
COLOR=0;
SIZE_X=0.8; SIZE_Y=0.75;

switch fig_type
 case 'fig1'
   load('test_signals.mat','impulse_sig');
   zc=get_zc(impulse_sig); zp=get_zp(impulse_sig);
   clf; figure(1);   
   do_plot_time(imag(zc),imag(zp));
   title(['Fig 1. Imaginary part of analytic signals formed from an ' ...
          'impulse signal']);   

 case 'fig2'
   load('test_signals.mat','impulse_sig');
   zc=get_zc(impulse_sig); zp=get_zp(impulse_sig);
   Zc=fft(zc); Zp=fft(zp);
   N=length(impulse_sig); N2=2*N;
   clf; figure(1);
   do_plot_frequency(Zc,Zp,N,N2);
   title(['Fig 2. Discrete spectra of the two analytic signals formed ' ...
          'from the impulse signal']);

 case 'fig3a'
   load('test_signals.mat','sin_sig');
   zc=get_zc(sin_sig); zp=get_zp(sin_sig);
   Zc=fft(zc); Zp=fft(zp);
   N=length(sin_sig); N2=2*N;
   clf; figure(1);
   subplot(2,1,1);
   do_plot_frequency(Zc,Zp,N,N2);
   title(['Fig 3a. Discrete spectra of the two analytic signals ' ...
          'formed from the sinusoidal signal']);
   
   subplot(2,1,2);   
   do_plot_frequency_zoom(Zc,Zp,N,N2);   
   title('Zoom of Fig 3a.');
   
 case 'fig3b'
   load('test_signals.mat','eeg_test_epoch');
   eeg_test_epoch=eeg_test_epoch(1:99);
   zc=get_zc(eeg_test_epoch); zp=get_zp(eeg_test_epoch);
   Zc=fft(zc); Zp=fft(zp);
   N=length(eeg_test_epoch); N2=2*N;
   clf; figure(1);   
   subplot(2,1,1);
   do_plot_frequency(Zc,Zp,N,N2);
   title(['Fig 3b. Discrete spectra of the two analytic signals ' ...
          'formed from the EEG signal']);
   
   subplot(2,1,2);   
   do_plot_frequency_zoom(Zc,Zp,N,N2);   
   title('Zoom of Fig 3b.');
   
   
 case 'fig4'
   load('test_signals.mat','impulse_sig');
   zc=get_zc(impulse_sig); zp=get_zp(impulse_sig);   
   clf; figure(1);   
   do_plot_dwvd(zc,zp,2);

   
 case 'fig5'
   load('test_signals.mat','eeg_test_epoch');
   zc=get_zc(eeg_test_epoch); zp=get_zp(eeg_test_epoch);
   clf; figure(1);   
   do_plot_dwvd(zc,zp,4);
   
   
   
 otherwise
  warning('Must be either fig1, fig2, fig3a, fig3b, fig4, or fig5');
  error(['Wrong fig_type: ' fig_type]);

end



%-------------------------------------------------------------------------------
% Time-domain plot
%-------------------------------------------------------------------------------
function do_plot_time(zc,zp)
clf;
N=length(zc);
t=1:N;
plot(t,zc,'-+',t,zp,'-o');
legend('conventional','proposed');
xlabel('time (samples)');



%-------------------------------------------------------------------------------
% Plot Spectra
%-------------------------------------------------------------------------------
function do_plot_frequency(Zc,Zp,N,N2)
% $$$ clf;
f=1:N2;

% 1. Take |.|^2 and normalise
aZc=(abs(Zc).^2); aZp=(abs(Zp).^2);
norm_factor=max(max(aZc),max(aZp));
aZc=aZc./norm_factor; aZp=aZp./norm_factor;

% 2. Shift so that negative freq. indices are first
aZc_pos=aZc(1:N);
aZc_neg=aZc((N+2):N2);
aZc_shift=[aZc_neg; aZc_pos; aZc(N+1)];  
aZp_pos=aZp(1:N);
aZp_neg=aZp((N+2):N2);
aZp_shift=[aZp_neg; aZp_pos; aZp(N+1)];  

% 3. Plot
plot(f,aZc_shift,'-+',f,aZp_shift,'-o');
legend('conventional','proposed');
xlabel('frequency (normalised)');
ylabel('magnitude squared (normaliased)');
set(gca,'xtick',[1, N, N2]);
set(gca,'xticklabel',{'-0.5','0','0.5'});



%-------------------------------------------------------------------------------
% Plot Spectra for frequency f range -0.25 < f < 0
%-------------------------------------------------------------------------------
function do_plot_frequency_zoom(Zc,Zp,N,N2)
f=1:N2;

% 1. Take |.|^2 and normalise
aZc=(abs(Zc).^2); aZp=(abs(Zp).^2);
norm_factor=max(max(aZc),max(aZp));
aZc=aZc./norm_factor; aZp=aZp./norm_factor;

% 2. Select portion of spectra.
freq_range=(N+2):N2;
N_freq_range=length(freq_range);
aZc_neg=aZc(freq_range); 
aZp_neg=aZp(freq_range);
f=1:N_freq_range;

% 3. Plot portion of spectra.
plot(f,aZc_neg,'-+',f,aZp_neg,'-o');
legend('conventional','proposed');
xlabel('frequency (normalised)');
ylabel('magnitude squared (normaliased)');
set(gca,'xtick',[1, N_freq_range]);
set(gca,'xticklabel',{'-0.25','0'});



%-------------------------------------------------------------------------------
% DWVD image plot
%-------------------------------------------------------------------------------
function do_plot_dwvd(zc,zp,no_plots)
clf;
% $$$ w_zc=dwvd_B(zc)(:,1:2:end);
% $$$ w_zp=dwvd_B(zp)(:,1:2:end);
w_zc=dwvd_B(zc);
w_zp=dwvd_B(zp);
[N,M]=size(w_zc);
b=-0.4;


if(no_plots==2) 
  fig_str='Fig 4'; 
else 
  fig_str='Fig 5';
end

figure(1); clf;
if(no_plots==2)
  subplot(1,2,1);
else
  subplot(2,2,1);
end
colormap(flipud(gray));
brighten(b);
imagesc(abs(w_zc));
axis('xy');
axis([1 M 1 N]);
xlabel('Frequency (normalised)');
ylabel('Time (samples)');
title([fig_str 'a DWVD using conventional analytic signal.']);
set(gca,'xtick',[1, N]);
set(gca,'xticklabel',{'0','0.5'});


if(no_plots==2)
  subplot(1,2,2);
else
  subplot(2,2,2);
end
imagesc(abs(w_zp));
axis('xy');
axis([1 M 1 N]);
xlabel('Frequency (normalised)');
ylabel('Time (samples)');
title([fig_str 'b DWVD using proposed analytic signal.']);
set(gca,'xtick',[1, N]);
set(gca,'xticklabel',{'0','0.5'});




if(no_plots==4)
  subplot(2,2,3);  
  w_zc_zoom=w_zc(:,fix(M/2):end);
  w_zc_zoom(1,1)=0.3; % So both have same scale.
  imagesc(abs(w_zc_zoom));
  axis('xy');
  axis([1 fix(M/2)+1 1 N]);
  xlabel('Frequency (normalised)');
  ylabel('Time (samples)');
  title('Fig 5c Zoom of Fig 5a.');
  set(gca,'xtick',[1, size(w_zc_zoom,2)]);
  set(gca,'xticklabel',{'0.25','0.5'});
  
  
  
  subplot(2,2,4);
  w_zp_zoom=w_zp(:,fix(M/2):end);
  w_zp_zoom(1,1)=0.3; % So both have same scale.
  imagesc(abs(w_zp_zoom));
  axis('xy');  
  axis([1 fix(M/2)+1 1 N]);  
  xlabel('Frequency (normalised)');
  ylabel('Time (samples)');
  title('Fig 5d Zoom of Fig 5b.');  
  set(gca,'xtick',[1, size(w_zc_zoom,2)]);
  set(gca,'xticklabel',{'0.25','0.5'});
end

