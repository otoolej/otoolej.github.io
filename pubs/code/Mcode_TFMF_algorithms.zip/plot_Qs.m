%-------------------------------------------------------------------------------
% Plot the 6 Q values over different SNRs.  Called by figure_2.m
%
% USE: plot_Qs(Qs,dBs)
%
% INPUT:
%      Qs = 6xN matrix for values of Q for 6 different signal types
%      dBs = vector with N dBs values
%
% EXAMPLE:
%      Qs=performance_Q(10,30,10);
%      plot_Qs(Qs);
%
% For plotting figure 2 in [1].  If you use this code in your research
% or publications, please reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009
%
%

%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function plot_Qs(Qs,dBs)
if(nargin<2) dBs=1:(size(Qs,2)); end

L=length(dBs);

FONT_SIZE=18;
FONT_TYPE='Helvetica';
FONT_TYPE='Times-Roman';
font_switch=['-F' FONT_TYPE ':' num2str(FONT_SIZE)];


line_colors=get(gca,'ColorOrder');

line_width=2;
marker_size=28; 

figure(1); clf;  
h=plot(dBs,Qs(1,:),'-+',dBs,Qs(2,:),'-d',dBs,Qs(3,:),'-x', ...
  dBs,Qs(4,:),'-s',dBs,Qs(6,:),'-^',dBs,Qs(5,:),'-o');

set(h,'MarkerSize',6);
legend('IMPULSE','UNIT STEP','LFM','PULSE TRAIN','WGN','WHALE',4);
axis([dBs(1) dBs(L) 0 1.2]);
xlabel('SNR (dBs)','FontName',FONT_TYPE,'FontSize',FONT_SIZE);
ylabel('Q = d_{AN} / d_{RE}','FontName',FONT_TYPE,'FontSize', ...
       FONT_SIZE);
