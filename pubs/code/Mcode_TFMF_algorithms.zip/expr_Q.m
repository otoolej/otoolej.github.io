%-------------------------------------------------------------------------------
% Function to compare performance of envelope matched filter with and
% without analytic signal.
%
% USAGE:
%        Q=expr_Q(signal);
%
%
% Calculates Q value from [1]. If you use this code in your research
% or publications, please reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009

%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function Q=expr_Q(s)
if(nargin<1) error('Need to input signal.'); end
N=length(s);
DB_STATUS=1;
% turn this on if have waitbar function:
WAITBAR=1; 


%---------------------------------------------------------
% Declar vars.
%---------------------------------------------------------
N2=N*2; 
% Number of iterations for 'experimental' method
M=1000;                                 
% Noise variance 
No=1; 


%---------------------------------------------------------
% Initialise random variables ...
%---------------------------------------------------------
if(DB_STATUS)
  disp(' | Intialise noise realisations ..');
end

% Zero-mean, and force constant variance.
w=randn(M,N);  
for mm=1:M
  w(mm,:)=normalise_w(w(mm,:),No);
end
  
%---------------------------------------------------------
% and then convert to complex-valued analytic signal
%---------------------------------------------------------
if(DB_STATUS)
  disp('. | analytic signal ..');
end

s_anal_u=get_analytic(s(:)); 

for mm=1:M
  if(WAITBAR) h_wait=waitbar(mm/M); end
  w_anal_u(mm,:)=get_analytic(w(mm,:)); 
end


%---------------------------------------------------------
% Get Q value:
%---------------------------------------------------------
if(DB_STATUS)
  disp('. | get SNRs ..');
end
KK=1;
snr_real=zeros(KK,1); snr_u=zeros(KK,1); Q=zeros(KK,1);

[Q,snr_real,snr_anal]=cal_perf_expr(s,w,s_anal_u,w_anal_u);


if(~isempty(h_wait)) delete(h_wait); end

%-------------------------------------------------------------------------------
% Get SNR using EXPERIMENTAL method, i.e.
%
% SNR = |E{eta_1}-E{eta_0}|/sqrt(0.5*{var(eta_1)+var(eta_0)})
%-------------------------------------------------------------------------------
function [Q,snr_real,snr_anal]= cal_perf_expr(s,w,s_anal_u,w_anal_u)
M=size(w,1);
eta_1_u=zeros(M,1); eta_0_u=zeros(M,1);
eta_1=zeros(M,1); eta_0=zeros(M,1);
s=s(:);

for n=1:M
  ww=w(n,:); ww=ww(:);
  ww_anal=w_anal_u(n,:); ww_anal=ww_anal(:);
  eta_1(n) = mf_quad(s+ww,s);
  eta_0(n) = mf_quad(ww,s);    
  eta_1_u(n) = mf_quad(s_anal_u+ww_anal,s_anal_u);
  eta_0_u(n) = mf_quad(ww_anal,s_anal_u);    
end

snr_real=snr_mf(eta_1,eta_0);
snr_anal=snr_mf(eta_1_u,eta_0_u);  

Q=snr_anal./snr_real;



%-------------------------------------------------------------------------------
% Calculate the time-domain matched filter 
%-------------------------------------------------------------------------------
function eta=mf_quad(f,s)
eta = abs(sum(f.*conj(s))).^2;


%-------------------------------------------------------------------------------
% Calculate deflection value
%-------------------------------------------------------------------------------
function p=snr_mf(eta_1,eta_0)
den = sqrt( 0.5*(var(eta_1)+var(eta_0)) );
p = abs(mean(eta_1) - mean(eta_0))/den;


%-------------------------------------------------------------------------------
% Force mean=0 and variance=1 for real or complex variables
%-------------------------------------------------------------------------------
function w=normalise_w(wr,No)
if(nargin<2) No=1; end

if(isreal(wr))
  w=(wr-mean(wr))./(sqrt(var(wr-mean(wr))./No));
else
  re=real(wr); im=imag(wr);
  w=(re-mean(re))./(sqrt(2.*var(re-mean(re))./No)) ...
    + j.*(im-mean(im))./(sqrt(2.*var(im-mean(im))./No));
end



