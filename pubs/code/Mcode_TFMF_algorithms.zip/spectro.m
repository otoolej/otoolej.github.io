%-------------------------------------------------------------------------------
% Spectrogram
%
% USE: sp = spectro(sig,w)
%
% INPUT:
%      sig = time-domain signal of length N
%      w = window
%
% OUTPUT:
%      sp = NxN spectrogram
%
% EXAMPLE:
%         N=128; n=0:N-1; fs=0.2; fst=0.4; 
%         sig=cos( 2*pi.*(fs.*n + ((fst-fs)/(2*N)).*(n.^2)) ); sig=sig(:);
%         w=get_window(floor(N/5),'tukey',0.4,0,N); 
%         sp=spectro(sig,w);
%         imagesc(fftshift(sp,2)); axis('xy');
%         xlabel('frequency');  ylabel('time');
%
% For plotting figure 2 in [1].  If you use this code in your research
% or publications, please reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009
%
%

%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function sp=spectro(x,y)
N=length(x);
L=length(y);
K=[]; sp=[];
if(L~=N) y=pad_win(y,N); end


K=zeros(N); 

m=0:N-1;
for n=0:N-1
  i1=mod(m-n,N);
  K(n+1,m+1)=x(m+1).*conj( y(i1+1) );
end


sp=abs(fft(K.').').^2;
if(nargout<1) ptfd(sp);  end

