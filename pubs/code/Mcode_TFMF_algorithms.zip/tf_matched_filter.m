%-------------------------------------------------------------------------------
%
% Time-frequency matched filter. See [1] for details.
%
%
% USE: [e_tf,g]=tf_matched_filter(x,y,kernel_type,kernel_params)
%
% INPUT: 
%   x = real-valued signal (received signal or known signal)
%
%   y = input real-valued signal (received signal or known signal)
%
%   (x and y are length-N)
%
%   kernel_type = { 'wvd' | 'swvd' | 'pwvd' | 'sep' | 'cw' | 'mb'}
%            wvd  - kernel for Wigner-Ville distribution
%            swvd - kernel for smoothed Wigner-Ville distribution
%                   (lag-independent kernel)
%            pwvd - kernel for pseudo Wigner-Ville distribution
%                   (dopple-independent kernel)
%            sep  - kernel for separable kernel (combintation of SWVD and PWVD)
%            cw   - kernel for Choi-Williams distribution
%            mb   - kernel for Modified-B distribution
% 
%   kernel_params = cell of kernel parameters:
%            wvd  - {}
%            swvd - {win_length,win_type,[win_param]}
%                   e.g. {11,'hamm'}
%            pwvd - {win_length,win_type,[win_param]}
%                   e.g. {200,'cosh',0.1
%            sep  - { {win1_length,win1_type,[win1_param]}, 
%                    {win2_length,win2_type,[win2_param]}
%                   where win1 is the doppler window and win2 is the lag window.
%                   e.g. { {11,'hamm'}, {200,'cosh',0.1} }
%            cw   - {sigma_parameter}
%            mb   - {beta_parameter} in the range 1<beta<0
%
%   N = signal length.
%
% OUTPUT:
%   e_tf = time-frequency test statistic
%   g = doppler--lag smoothing kernel
%
%
% EXAMPLE:
%         N=128; n=0:N-1; fs=0.2; fst=0.4; 
%         sig=cos( 2*pi.*(fs.*n + ((fst-fs)/(2*N)).*(n.^2)) );
%         r=sig+randn(1,N);
%         e_tf=tf_matched_filter(sig,r,'sep',{{N,'cosh',0.1},{255,'hamm'}});
%         imagesc(fftshift(real(e_tf))); axis('xy');
%         xlabel('frequency');  ylabel('time');
%
%
% Algorithm detailed in [1], Section 4.1.  If you use this code in
% your research or publications, please reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009
%
%



%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function [e_tf,g]=tf_matched_filter(x,y,kern_type,kern_params)
N=length(x);
L=length(y);
if(L~=N) error('Signals must be same length.'); end
if(nargin<2) error('Need to input signals.'); end
if(nargin<4) kern_type='cw'; kern_params=1; end
Nh=ceil(N/2);
VERBOSE=1;


%---------------------------------------------------------------------
% 0. Prerequisites
%---------------------------------------------------------------------
% Doppler-lag kernel.
g=dl_kern(kern_type,kern_params,N);
if(VERBOSE)
  disp(['-- Kernel type: ' upper(kern_type) ' --']);
end


%---------------------------------------------------------------------
% 1. Form the two time--lag functions
%---------------------------------------------------------------------
Kx=get_Kdown(x,N,Nh);
Ky=get_Kdown(y,N,Nh);


%---------------------------------------------------------------------
% 2. Transform to Doppler--lag domain
%---------------------------------------------------------------------
% LOAD = 2 x N/2 x RFFT_N  
Ax=fft(Kx);
Ay=fft(Ky);


%---------------------------------------------------------------------
% 3. Multiply ambiguity functions with kernel
% 
%---------------------------------------------------------------------
S=Ax.*conj(Ay).*g(:,1:Nh+1);


%---------------------------------------------------------------------
% 4. Now back to time-lag domain
%---------------------------------------------------------------------
% LOAD = N/2 x RFFT_N
%
% As complex conjugate FFT. Am assuming that TL kernel is real and
% symmetric in lag direction, as g(-\nu,\tau)=g^*(\nu,\tau) which is a
% bit more restrictive than the usual g(-\nu,-\tau)=g^*(\nu,\tau) to
% ensure that TFD is real-valued.
%
R=ifft(S);


%---------------------------------------------------------------------
% 5. Fill out in lag direction using the conjugate symmetry property
%---------------------------------------------------------------------
m=1:Nh-1;
R(:,N-m+1)=R(:,m+1);


%---------------------------------------------------------------------
% 6. Finally, produce test statistic in time-frequency domain
%---------------------------------------------------------------------
% LOAD = N/2 x RFFT_N  (real and symmetric DFT)
%
% Again, assuming that G(t,\tau) is real-valued and symmetric in lag,
% then can implement this using DCT (~ 1/2 of RFFT load).
e_tf=fft(R.').';




% Total load then is
%  - N x CFFT-N (complex FFTs of length N) when G(t,\tau) is
%    real-valued
%  - 3N/2 x CFFT-N when G(t,\tau) is complex valued 
%
% [assuming that TFD is real-valued and therefore
%  G(t,\tau)=G^*(t,\tau)]





function K=get_Kdown(x,N,Nh)
%-------------------------------------------------------------------------
% 1. Get antisymmetrical TL kernel K(nT,mT)
%
%    K(nT,mT) = x(n)x(n-m)
%-------------------------------------------------------------------------
K=zeros(N,Nh+1); 
m=0:Nh; 
for n=0:N-1
  i1=mod(n-m,N);   
  K(n+1,m+1) = x(n+1).*x(i1+1);
end

