%-------------------------------------------------------------------------------
% Compare the performance of matched filter with real-valued and
% analytic signal for 6 different signal types over different SNR values.
%
% USE: Qs=performance_Q(dB_max,dB_min,dB_step)
%
% INPUT:
%      dB_max = maximum dB value
%      dB_min = min dB value
%      dB_step = step value for dB vector
% 
% OUTPUT:
%      Qs = 6xN matrix for values of Q for 6 different signal types
%
% EXAMPLE:
%      Qs=performance_Q(10,30,10);
%      plot_Qs(Qs);
%
% Used to generate Qs values for figure 2 in [1].  If you use this
% code in your research or publications, please reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009

%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function Qs=performance_Q(dB_max,dB_min,dB_step)
if(nargin<1) dB_max=10; end
if(nargin<2) dB_min=-30; end
if(nargin<3) dB_step=2; end

dBs=linspace(dB_min,dB_max,round(abs(dB_max-dB_step-dB_min)/dB_step));
L=length(dBs);

Qs=zeros(6,L);

for l=1:L
  Qs(:,l)=perf_Q_SNR(dBs(l));
end


%-------------------------------------------------------------------------------
% 
%-------------------------------------------------------------------------------
function Q=perf_Q_SNR(a_dB)
if(nargin<1) a_dB=-10; end

Q=zeros(6,1);


%-------------------------------------------------------------------------
% 1. Impulse signal
%-------------------------------------------------------------------------
N1=128;
s1=zeros(N1,1); s1(50)=1; 
Q(1)=do_Q(s1,a_dB);

%-------------------------------------------------------------------------
% 2. Step signal
%-------------------------------------------------------------------------
N2=141;  
s2=ones(N2,1); s2(1:fix(N2/5))=0;
Q(2)=do_Q(s2,a_dB);    

%-------------------------------------------------------------------------
% 3. Linear frequency modulated signal
%-------------------------------------------------------------------------
N3=100;
n3=0:N3-1; fs=0.1; fst=0.4;
s3=cos(2*pi.*(fs.*n3 + ((fst-fs)/(2*N3)).*(n3.^2)));
Q(3)=do_Q(s3,a_dB);    

%-------------------------------------------------------------------------
% 4. Pulse train
%-------------------------------------------------------------------------
N4=201;
Pw=10; Tp=50;
ptrain=zeros(N4,1);
for l=0:floor(N4/(Pw+Tp))
  n=(l*Tp+l*Pw):(l*Tp+(l+1)*Pw);
  ptrain(n+1)=1;
end
Q(4)=do_Q(ptrain,a_dB);  

%-------------------------------------------------------------------------
% 5. Whale
%-------------------------------------------------------------------------
wh=load('whale1');
wh=wh(1:4096);
Q(5)=do_Q(wh,a_dB);

%-------------------------------------------------------------------------
% 6. White Gaussian noise
%-------------------------------------------------------------------------
Q(5)=do_Q(wh,a_dB);
N6=99;
s7=randn(N6,1);
Q(6)=do_Q(s7,a_dB);



%-------------------------------------------------------------------------
% Calculate the loss factor Q for at a specific dB value
%-------------------------------------------------------------------------
function Q=do_Q(s1,a_dB)
DB=1;

% Scale signal to fit dB value
a=10^(a_dB/10);
s1=real(s1);                  
s1= s1./sqrt( sum(abs(s1).^2)./length(s1) );
s1=s1.*sqrt(a);               


if(DB)
  disp(['dB of signal: ',num2str(10*log10( sum(abs(s1).^2)./length(s1) ))]);
end

Q=expr_Q(s1);

  


