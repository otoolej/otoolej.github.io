%-------------------------------------------------------------------------------
% Doppler-lag SMOOTHING kernels
%
% USE: g=dl_kern( kernel_type, kernel_params, N )
%
% INPUT: 
%
%   kernel_type = { 'wvd' | 'swvd' | 'pwvd' | 'sep' | 'cw' | 'mb'}
%            wvd  - kernel for Wigner-Ville distribution
%            swvd - kernel for smoothed Wigner-Ville distribution
%                   (lag-independent kernel)
%            pwvd - kernel for pseudo Wigner-Ville distribution
%                   (dopple-independent kernel)
%            sep  - kernel for separable kernel (combintation of SWVD and PWVD)
%            cw   - kernel for Choi-Williams distribution
%            mb   - kernel for Modified-B distribution
% 
%   kernel_params = cell of kernel parameters:
%            wvd  - {}
%            swvd - {win_length,win_type,[win_param]}
%                   e.g. {11,'hamm'}
%            pwvd - {win_length,win_type,[win_param]}
%                   e.g. {200,'cosh',0.1
%            sep  - { {win1_length,win1_type,[win1_param]}, 
%                    {win2_length,win2_type,[win2_param]}
%                   where win1 is the doppler window and win2 is the lag window.
%                   e.g. { {11,'hamm'}, {200,'cosh',0.1} }
%            cw   - {sigma_parameter}
%            mb   - {beta_parameter} in the range 1<beta<0
%
%   N = signal length.
%
% OUTPUT:
%   g = doppler--lag smoothing kernel
%
%
% EXAMPLE:
%      N=64; 
%      g=dl_kern( 'sep',{{N,'cosh',0.1},{51,'hamm'}},N); 
%      mesh( fftshift(g) );
%      xlabel('lag'); ylabel('doppler');
%      title('Separable kernel');
%
%
% If you use this code in your research or publications, please
% reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009
%
%

%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function g=dl_kern( kernel_type, kernel_params, N)
if(nargin<3) error('Need 3 input arguments.'); end
N2=N*2;  


lag_sample_rate=1;
doppler_sample_rate=1/N;
g=zeros(N,N2);
g=get_kern(g,kernel_type,kernel_params, ...
             doppler_sample_rate,lag_sample_rate,N2,N);


% Post-process the kernel.
% Doppler--lag kernel g should be periodic in Doppler the direction in
% N.  This equates to inserting zeros at odd time samples in the
% time--lag domain.
if( size(g,1)~=N2 )
  g_full=zeros(N2);
  g_full(1:N,:)=g;
  g_full((N+1):N2,:)=g;  
  g=g_full;
end


% All kernels are real valued. 
g=real(g);


% Could make this function more computational efficient as only
% return this:
g=g(1:2:end,1:2:end);



function g=get_kern(g,kernel_type,kernel_params,doppler_sample_rate, ...
                      lag_sample_rate,N2,N)
[Nd,Nl]=size(g);
d_hlf=floor(Nd/2);
l_hlf=floor((Nl-1)/2);
l=length(kernel_params);


switch kernel_type
  
 case {'wvd'}
  g(:,:)=1;

  
  %---------------------------------------------------------------------
  % Smoothed Wigner-Ville (Lag Independent (LI) kernel)
  % g(l/NT,mT) = W(l/NT)
  %---------------------------------------------------------------------
 case 'swvd'
  
  if( l<2 ) 
    error('Need at least two window parameters for SWVD'); 
  end
  win_length=kernel_params{1};
  win_type=kernel_params{2}; 
  win_param=0; win_param2=0;
  if( l>=3 ) win_param=kernel_params{3}; end
  if( l>=4 ) win_param2=kernel_params{4}; end
  

  G1=get_window(win_length,win_type,win_param);
  G1=pad_win(G1,Nd);
  
  
  % Define window in the time-domain (this is the usual practice):
  % But could also define in the doppler-domain.
  if( win_param2==0 )
    G1=fft(G1);
    G1=G1./G1(1);
  end
  
  if( isreal_fn(ifft(G1))==0 )
    warning('Window function g1(t) is NOT real valued.');
  end
  
  for m=1:Nl
      g(:,m) = G1;
  end
  
  
  %---------------------------------------------------------------------
  % Pseudo-Wigner-Ville (Doppler Independent (DI) kernel)
  % g(l/NT,mT) = g2(mT)
  %---------------------------------------------------------------------
 case 'pwvd'
  
  if( l<2 ) 
    error('Need at least two window parameters for PWVD'); 
  end
  P=kernel_params{1};
  win_type=kernel_params{2}; 
  win_param=0;   win_param2=0;
  if( l>2 ) win_param=kernel_params{3}; end
  if( l>3 ) win_param2=kernel_params{4}; end  

  g2=get_window(P,win_type,win_param,win_param2);
  g2=g2(:);
  g2=pad_win(g2,Nl);
    

  if( isreal_fn(fft(g2))==0 )
    warning('Window function G2(f) is NOT real valued.');
  end

  
  for l=0:Nd-1
      g(l+1,:)=g2;
  end

  %---------------------------------------------------------------------
  % Seperable Kernel
  %
  % g(l/NT,mT) = G1(l/NT)g2(mT) 
  %  
  %---------------------------------------------------------------------
 case { 'sep', 'sep-full' }

  if(l<2)
    error('Need at least two windows parameters.'); 
  end
    
  g1=get_kern(g, 'swvd', kernel_params{1}, doppler_sample_rate, ...
                 lag_sample_rate, N2, N);
  g2=get_kern(g, 'pwvd', kernel_params{2}, doppler_sample_rate, ...
                 lag_sample_rate, N2, N);
  g=g1.*g2;

  
  
  %---------------------------------------------------------------------
  % Choi-Williams
  %
  % g(l/NT,mT) = exp( -(2 pi m l/N)^2/ sigma ) 
  %
  %---------------------------------------------------------------------
 case {'cw', 'choi-williams', 'choi-will'}
  
  if(l>1) 
    sigma=kernel_params{1};
  elseif(l==1) 
    sigma=kernel_params;
  else
    sigma=11;
  end
  
  
  g(1,1:Nl) = 1;
  g(1:Nd,1) = 1;
  g(1,l_hlf+2) = 0;
  
   const = ((2*pi)^2)/sigma;
   u=1:d_hlf;
   for m=1:l_hlf
     u1=u.*doppler_sample_rate; m1=m*lag_sample_rate;
     g(u+1,m+1) = exp( -const.*(u1.*m1).^2 ).';
     
     g(Nd - u + 1, m + 1) = g(u + 1, m + 1); 
     g(u + 1, Nl - m + 1) = g(u + 1, m + 1); 
     g(Nd - u + 1, Nl - m + 1) = g(u + 1, m + 1); 
   end
   
  %---------------------------------------------------------------------
  % Modified-B (a specific SWVD or LAG INDEPENDENT kernel)
  %
  % G(nT,mT) = cosh^{-2*beta}(n)   (defined in time--lag domain)
  %---------------------------------------------------------------------
 case { 'mb', 'modified-b' }
  if(l>1) 
    beta=kernel_params{1};
  elseif(l==1) 
    beta=kernel_params;
  else
    beta=0.1;
  end

  g=get_kern(g, 'swvd', {N,'cosh',beta}, doppler_sample_rate, ...
                 lag_sample_rate, N2, N);
    
  
 otherwise
  error(['Unknown kernel type: ' kernel_type]);
  
end



function G_holes=poke_holes_in_G(G,N)
N2=N*2;
G_holes=zeros(N2);

m=0:N-1; nn=0;
for n=0:2:N2-2
  G_holes(n+1,2.*m+1)=G(nn+1,2.*m+1);
  G_holes(n+2,2.*m+2)=G(nn+2,2.*m+2);      
  nn=nn+2;
end


function flag = isreal_fn(fn,E)
% ISREAL_FN - is 'fn' real valued

if(nargin<2)
  E=sum(abs(fn).^2) * 1e-12;
end
flag=1;

if( max(max( abs(imag(fn)) )) > E ) flag=0; end



