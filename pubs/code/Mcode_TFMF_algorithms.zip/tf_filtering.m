%-------------------------------------------------------------------------------
%
% Filter in the time--Frequency domain and return the ambiguity
% function. Part of the masked time-frequency matched filter algorithm
% in [1].
%
%
% USE: AF_mask = tf_filtering(sig,mask)
%
% INPUT: 
%   sig = length-N signal
%   mask = 2NxN time-frequency mask (filter function)
%
% OUTPUT:
%   AF_mask = ambiguity function for sig after multiplying the WVD
%             of sig with mask (for positive lag values only)
%
% EXAMPLE:
%         N=128; n=0:N-1; fs=0.2; fst=0.4; 
%         sig=cos( 2*pi.*(fs.*n + ((fst-fs)/(2*N)).*(n.^2)) );
%         % Filter out a certain portion of received signal:
%         m=ones(2*N,N); m(:,1:50)=0;
%         AF_mask=tf_filtering(sig,m);
%         imagesc(fftshift(abs(AF_mask),1)); axis('xy');
%         xlabel('lag');  ylabel('Doppler');
%
%
% Algorithm detailed in [1], Section 4.3.  If you use this code in
% your research or publications, please reference [1].
%
%
% [1] J.M. O' Toole, M. Mesbah, B. Boashash, "Accurate and efficient
% implementation of the time-frequency matched filter", IET Signal
% Process., Special Issue of Time-Frequency Approach to Radar
% Detection, Imaging, and Classification, submitted for publication,
% 2009
%
%

%
%   Copyright (c) 2009, John M. O' Toole, The University of Queensland
%   All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following
%  conditions are met:
%      * Redistributions of source code must retain the above
%        copyright notice, this list of conditions and the following
%        disclaimer.
%      * Redistributions in binary form must reproduce the above
%        copyright notice, this list of conditions and the following
%        disclaimer in the documentation and/or other materials
%        provided with the distribution.
%      * Neither the name of the <organization> nor the names of its
%        contributors may be used to endorse or promote products
%        derived from this software without specific prior written
%        permission.
%  
%  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
%  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
%  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
%  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
%  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
%  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
%  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
%  DAMAGE.
%
%-------------------------------------------------------------------------------
function Amask=tf_filtering(x,mask)
N=length(x);
N2=N*2; Nh=ceil(N/2);


 % If no mask given then generate one using the spectrogram of the signal
if(nargin<2 | isempty(mask))
  % 1a. Interpolate real-valued signal by factor of 2
  x_interp=real( ifft( pad_win(fft(x),N2) ) );
  % 1b. Zero pad to length 3N
  x_interp=[x_interp; zeros(N2,1)];
  % 1c. Get the spectrogram but only return a portion of it
  mask=spectro(x_interp,fftshift(hamming(floor(N/5))));
  mask=mask(1:N2,1:N); 
end 


%-------------------------------------------------------------------------
% 1. Get symmetrical TL kernel K(nT/2,mT)
%-------------------------------------------------------------------------
K=zeros(N,N); 
n=0:N-1; 
for m=0:Nh
  i1=mod(n+m,N); i2=mod(n-m,N); i3=mod(n+m+1,N);
  K(2.*n+1,m+1) = x(i1+1).*conj(x(i2+1));
  K(2.*n+2,m+1) = x(i3+1).*conj(x(i2+1));  
end

m=1:Nh-1; 
K(1:2:end,N-m+1) = conj( K(1:2:end,m+1));
m=0:Nh-1; 
K(2:2:end,N-m-1+1) = conj( K(2:2:end,m+1));


%-------------------------------------------------------------------------
% 2. FFT to time--frequency domain
%-------------------------------------------------------------------------
wx=fft(K.').';


%-------------------------------------------------------------------------
% 3. Time--frequency filter
%-------------------------------------------------------------------------
wm=wx.*mask;


%-------------------------------------------------------------------------
% 4. Back to the time--lag domain
%-------------------------------------------------------------------------
R=(ifft(wm.').');


%-------------------------------------------------------------------------
% 5. Shift time--lag array to Rdown.
%-------------------------------------------------------------------------
Rdown=zeros(N,Nh+1);
n=0:N-1;
for m=0:Nh-1
  Rdown(n+1,2*m+1)=R(2.*n+1,m+1);
  Rdown(n+1,2*m+2)=R(2.*n+2,m+1);    
end
m=Nh;
if(rem(N,2)==0)
  Rdown(n+1,2*m+1)=R(2.*n+1,m+1);
else
  Rdown(n+1,2*m+2)=R(2.*n+2,m+1);
end


%-------------------------------------------------------------------------
% 6. And finally, Doppler--lag domain.
%-------------------------------------------------------------------------
Amask=fft(Rdown(:,1:Nh+1));



