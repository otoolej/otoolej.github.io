Discrete Time-Frequency Distributions
=====================================

* Description
  This collection of M-files generate the different discrete
  time-frequency distribution (DTFD) definitions [1].  These
  defintions are different ways to represent the continuous
  time-frequency distributions.  (We consider only the class of
  quadratic time-frequency distributions.)

  These programs should run in either Matlab (v7.5.0) or Octave
  (v3.0.0). Included,

  1) functions to generate the DTFD definitions:
     - gdtfd.m generates the 'generalised DTFD' definition [3]
     - af_gdtfd.m generates the 'alias-free generalised DTFD'
       definition [4]
     - dtfd_C.m generates the proposed DTFD definition [1]

  2) functions to generate some of the results in paper [1]:
     - plot_figures.m plots Figs. 5 and 6 
     - test_properties.m tests the properties for proposed DTFD

  3) other functions used by to generate the DTFDs:
     - get_analytic.m generates the discrete analytic signal [2]
     - get_dl_kernel.m generates the doppler--lag kernel
     - get_window.m generates a 1D smoothing function
     - dwvd_B_full.m generates a full-plane, definition-B, DWVD [1]
     - dwvd_C.m generates a half-plane, definition-C, DWVD [1]
     - force_props.m generates a modified kernel constraining the
       kernel so as the resultant DTFD may satisfy a certain property
     - tf_conv.m convolves two time--frequency functions in time and
       frequency.
    

* Examples
  1) to generate Choi-Williams using the proposed DTFD [1] definition

     N=128; f=0.1; N2=2*N; n=0:N-1;
     sig1=cos( 2*pi*f.*n);     
     fs=0.2; fst=0.4;
     sig2=cos( 2*pi.*(fs.*n + ((fst-fs)/(2*N)).*(n.^2)) );
     c=dtfd_C(sig1+sig2,'cw',{100}); 
     imagesc(c); axis('xy');
     xlabel('frequency');  ylabel('time');

  2) to generate a smoothed WVD using the AF-GDTFD [4] definition 

     N=128; f=0.1; N2=2*N; n=0:N-1;
     fs=0.2; fst=0.4;
     sig2=cos( 2*pi.*(fs.*n + ((fst-fs)/(2*N)).*(n.^2)) );
     a=af_gdtfd(sig2,'swvd',{fix(N/3),'hamm'}); 
     imagesc(fftshift(a,2)); axis('xy');
     xlabel('frequency');  ylabel('time');

  3) to compare the AF-GDTFD with the proposed DTFD for a linear FM
     signal
     
     plot_figures('fig3');

  4) to test the frequency marginal property in the proposed DTFD
     kernel

     test_properties('freqmarginal',1,0);




* Test computer setup
  - hardware:  Intel Core Duo CPU, 2.6GHz; 4GB memory.
  - operating system: Ubuntu GNU/Linux x86_64 distribution (Hardy, 8.04), 
     with Linux kernel 2.6.24-19-generic. 
  - software: Octave 3.0.0 (using Gnuplot 4.2 patchlevel 2) and 
     Matlab 7.5.0


* Copyright
  Copyright (C) 2007,2008 John M. O' Toole, The University of Queensland
  Email: 	  j.otoole@ieee.org

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following
  conditions are met:
      * Redistributions of source code must retain the above
        copyright notice, this list of conditions and the following
        disclaimer.
      * Redistributions in binary form must reproduce the above
        copyright notice, this list of conditions and the following
        disclaimer in the documentation and/or other materials
        provided with the distribution.
      * Neither the name of the John M. O' Toole nor the names of its
        contributors may be used to endorse or promote products
        derived from this software without specific prior written
        permission.
  
  THIS SOFTWARE IS PROVIDED BY JOHN M. O' TOOLE ''AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JOHN M. O' TOOLE BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
  DAMAGE.

* References
  [1] J. M. O' Toole, M. Mesbah, and B. Boashash, "Improved Discrete
  Definition of Quadratic Time-Frequency Distributions", IEEE Trans. on Signal
  Processing, vol. 58, no. 2, Feb. 2010
  [Online]. Available: doi:10.1109/TSP.2009.2031287

  [2] J. M. O' Toole, M. Mesbah, and B. Boashash, "A New Discrete
  Analytic Signal for Reducing Aliasing in the Discrete
  Wigner-Ville Distribution", IEEE Trans.  on Signal Processing,
  vol. 56, no. 11, pp. 5427-5434, Nov. 2008.

  [3] B. Boashash and A. Reilly, "Algorithms for time--frequency
  signal analysis," in Time--Frequency Signal Analysis: Methods and
  Applications, B. Boashash, Ed.  Melbourne 3205: Wiley Press, 1992,
  ch.~7, pp. 163--181.

  [4] J.C. O' Neill and W.J. Williams, "Shift covariant
  time--frequency distributions of discrete signals," IEEE
  Trans. Signal Processing, vol. 47, no. 1, pp. 133--146, Dec. 1999.

  

* Contact
   - John M. O' Toole,  
   - The University of Queensland,
     Perinatal Research Centre and UQ Centre for Clinical Research,
     Building 71/918,
     Royal Brisbane Hospital,
     Herston, 
     Queensland 4029,
     Australia.
   - Phone + 61 7 33466113
   - Email j.otoole@ieee.org	
